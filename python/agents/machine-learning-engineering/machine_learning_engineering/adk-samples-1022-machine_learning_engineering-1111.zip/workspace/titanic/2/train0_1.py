
import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier # Added for reference solution
from sklearn.metrics import accuracy_score

# Load data from the specified ./input directory
train_df = pd.read_csv(os.path.join('input', 'train.csv'))
test_df = pd.read_csv(os.path.join('input', 'test.csv'))

# Combine for preprocessing
all_data = pd.concat([train_df.drop('Survived', axis=1), test_df], ignore_index=True)

# Simple Preprocessing
# Drop irrelevant columns
all_data.drop(['PassengerId', 'Name', 'Ticket', 'Cabin'], axis=1, inplace=True)

# Fill missing 'Age' with median
all_data['Age'].fillna(all_data['Age'].median(), inplace=True)

# Fill missing 'Fare' with median (relevant for test_df primarily)
all_data['Fare'].fillna(all_data['Fare'].median(), inplace=True)

# Fill missing 'Embarked' with mode
all_data['Embarked'].fillna(all_data['Embarked'].mode()[0], inplace=True)

# Encode categorical features
le = LabelEncoder()
all_data['Sex'] = le.fit_transform(all_data['Sex'])
all_data = pd.get_dummies(all_data, columns=['Embarked', 'Pclass'], drop_first=True)

# Split back into train and test
X_train_processed = all_data.iloc[:len(train_df)]
# X_test_processed is for actual test set predictions, not used for validation score.
# However, it's created as part of the preprocessing pipeline.
X_test_processed = all_data.iloc[len(train_df):]
y_train = train_df['Survived']

# Train-test split for validation
X_train_model, X_val_model, y_train_model, y_val_model = train_test_split(
    X_train_processed, y_train, test_size=0.2, random_state=42
)

# Initialize and train XGBoost Classifier (from base solution)
xgb_model = XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=42)
xgb_model.fit(X_train_model, y_train_model)

# Initialize and train LightGBM Classifier (from reference solution)
lgbm_model = LGBMClassifier(random_state=42, verbose=-1) # verbose=-1 to suppress warnings
lgbm_model.fit(X_train_model, y_train_model)

# Make predictions (probabilities) on the validation set for both models
# We use predict_proba to get probabilities for ensembling
xgb_preds_proba = xgb_model.predict_proba(X_val_model)[:, 1] # Probability of class 1
lgbm_preds_proba = lgbm_model.predict_proba(X_val_model)[:, 1] # Probability of class 1

# Ensemble the predictions by averaging probabilities
# Then convert averaged probabilities to binary predictions using a threshold (0.5)
ensemble_preds_proba = (xgb_preds_proba + lgbm_preds_proba) / 2
y_pred_ensemble = (ensemble_preds_proba >= 0.5).astype(int)

# Evaluate the ensembled model using accuracy
accuracy = accuracy_score(y_val_model, y_pred_ensemble)

# Print the final performance metric in the required format
print(f"Final Validation Performance: {accuracy}")

